/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;
import java.awt.Color;
import ljs.gui.looicanvas.three_dimensional.World.ArrayPoint;
import ljs.gui.looicanvas.utilities.Supplier;

/**
 *
 * @author peter_000
 */
public class Floor extends Polygon3D
    {
        ////////////////////////////
        private Container myContainer;
        private World myWorld;
        private ArrayPoint upperLeft,upperRight,lowerRight,lowerLeft;
        Floor(ArrayPoint upperLeft, ArrayPoint upperRight, ArrayPoint lowerRight, ArrayPoint lowerLeft, World myWorld, Color myColor, Supplier<View> view)
            {
                super(myColor,view,upperLeft,upperRight,lowerRight,lowerLeft);
                myContainer = addMeToContainer(getCenter(),myWorld);
                this.myWorld = myWorld;
                this.upperLeft = upperLeft;
                this.upperRight = upperRight;
                this.lowerRight = lowerRight;
                this.lowerLeft = lowerLeft;
            }
        public Point3D getCenter()
            {
                return super.getCenter();
            }
        public ArrayPoint[] getCorners()
        {
            return new ArrayPoint[] {upperLeft,upperRight,lowerRight,lowerLeft};
        }
        public Container addMeToContainer(Point3D center, World world)
            {
                Container myContainer = world.getCorrectContainer(center);
                myContainer.getNoBlur().add(this); 
                return myContainer;
            }
    }