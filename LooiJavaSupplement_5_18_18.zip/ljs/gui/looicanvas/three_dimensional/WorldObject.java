/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;

import ljs.gui.looicanvas.utilities.Supplier;


/**
 *
 * @author peter_000
 */
public abstract class WorldObject extends Object3D
{
    private World myWorld;
    public WorldObject(Supplier<View> view, Point3D center, World myWorld) 
    {
        super(view, center);
        this.myWorld = myWorld;
    }
    public World getMyWorld()
    {
        return myWorld;
    }
    protected void goToGround()
    {
        Floor f = getFloorUnderneath();
        getCenter().setY(f.getCenter().getY()); 
    }
    protected Floor getFloorUnderneath()
    {
        return myWorld.getCorrectFloor(getCenter());
    }
}
