/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui;

import ljs.Obj;
import java.lang.InterruptedException;
/**
 *
 * @author peter_000
 */
public abstract class Component extends Obj
{
	
    public static final int 
            default_x = 0,
            default_y = 0,
            default_width = 200,
            default_height = 200,
			default_location_thread_iteration_wait = 75;
    
    private java.awt.Component javaComponent;
    private Thread locationThread;
    private boolean locationThreadRunning = false;
    private boolean locationThreadOn = false;
	private long locationThreadIterationWait = default_location_thread_iteration_wait;
    public Component(java.awt.Component javaComponent)
    {
        this.javaComponent = javaComponent;
        if(javaComponent != null)
            javaComponent.setBounds(default_x,default_y,default_width,default_height);
    }
    public java.awt.Component getJavaComponent(){return javaComponent;}
    protected void setJavaComponent(java.awt.Component jc)
    {
        this.javaComponent = jc;
        if(javaComponent != null)
            javaComponent.setBounds(default_x,default_y,default_width,default_height);
    }
    public void setBounds(int x, int y, int width, int height)
    {
        locationThreadRunning = false;
        while(locationThreadOn){try{Thread.sleep(2);}catch(Exception e){}}
        javaComponent.setBounds(x,y,width,height);
    }
    public void setBounds(Getter<Integer> x, Getter<Integer> y, Getter<Integer> width, Getter<Integer> height)
    {
        locationThreadRunning = false;
        while(locationThreadOn){try{Thread.sleep(2);}catch(Exception e){}}
        locationThread = new Thread(()->
        {
            while(locationThreadRunning)
            {
                javaComponent.setBounds(x.get(),y.get(),width.get(),height.get());
                postResizeActions();
				try{Thread.sleep(locationThreadIterationWait);}catch(InterruptedException ex){}
            }
            locationThreadOn = false;
        });
        locationThreadOn = true;
        locationThreadRunning = true;
        locationThread.start();
    }
    public void postResizeActions() {}
    public void setVisible(boolean visible)
    {
        javaComponent.setVisible(visible);
    }
    public boolean isVisible(){return javaComponent.isVisible();}
    public int getX(){return javaComponent.getX();}
    public int getY(){return javaComponent.getY();}
    public int getWidth(){return javaComponent.getWidth();}
    public int getHeight(){return javaComponent.getHeight();}
    
    public static interface Getter<E>
    {
        public E get();
    }
	
    public long getLocationThreadIterationWait(){return locationThreadIterationWait;}
	public void setLocationThreadIterationWait(long l){locationThreadIterationWait = l;}
}
