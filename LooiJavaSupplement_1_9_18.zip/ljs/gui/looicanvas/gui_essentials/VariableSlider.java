/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import ljs.gui.looicanvas.utilities.InputAction;
import ljs.gui.looicanvas.utilities.Supplier;

/**
 *
 * @author peter_000
 */
public abstract class VariableSlider<E> extends Slider
{
    private InputAction<E> setter;
    private Supplier<E> getter;
    private E max;
    private E min;
    public VariableSlider(double x, double y, double width, double height, Background background, E min, E max, InputAction<E> setter, Supplier<E> getter)
    {
        super(x, y, width, height, background);
        setMax(max);
        setMin(min);
        this.getter = getter;
        this.setter = setter;
    }
    //public Supplier<E> getGetter(){return getter;}
    //public void setGetter(Supplier<E> getter){this.getter = getter;}
    protected void looiStep()
    {
        super.looiStep();
        setter.act(findProportionalValue(max,min,getFraction()));
    }
    public void setVariable(E val)
    {
        slideToFraction(findFractionFrom(max,min,val));
        setter.act(val);
    }
    
    public E getMax(){return max;}
    public E getMin(){return min;}
    public void setMax(E e){max = e;}
    public void setMin(E e){min = e;}
    protected abstract double findFractionFrom(E max, E min, E val);
    protected abstract E findProportionalValue(E max, E min, double fraction);
}
