/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;
import java.awt.Color;
import java.io.Serializable;
import ljs.gui.looicanvas.Calculations;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.three_dimensional.World.ArrayPoint;
import ljs.gui.looicanvas.utilities.Supplier;

/**
 *
 * @author peter_000
 */
public class Container extends BlurrableObject3D implements Serializable
    {
        public static final double 
                DEFAULT_HIGHEST_PROBABILITY_ACTIVATION = .4,
                DEFAULT_LOWEST_PROBABILITY_ACTIVATION = .1,
                DEFAULT_HIGHEST_PROBABILITY_DEACTIVATION = .4,
                DEFAULT_LOWEST_PROBABILITY_DEACTIVATION = .1,
                DEFAULT_GUARANTEED_ACTIVATION_DISTANCE = 2000,
                DEFAULT_DEFINITION_OF_ANGLE_IN_FRONT = 120;
                
        //static constructor
        ///////
        private double 
                guaranteedActivationDistance = DEFAULT_GUARANTEED_ACTIVATION_DISTANCE,
                definitionOfAngleInFront = DEFAULT_DEFINITION_OF_ANGLE_IN_FRONT,
                highestProbabilityActivation = DEFAULT_HIGHEST_PROBABILITY_ACTIVATION,
                lowestProbabilityActivation = DEFAULT_LOWEST_PROBABILITY_ACTIVATION,
                highestProbabilityDeactivation = DEFAULT_HIGHEST_PROBABILITY_DEACTIVATION,
                lowestProbabilityDeactivation = DEFAULT_LOWEST_PROBABILITY_DEACTIVATION,
                highBlurDistance,
                mediumBlurDistance,
                disappearDistance;
        private Point3D center;
        private ArrayPoint 
                upperLeft,
                upperRight,
                lowerRight,
                lowerLeft,
                UL,//for the blurs
                UR,
                LR,
                LL,
                south,
                east,
                north,
                west,
                middle;
        private Supplier<View> view;
        private World myWorld;
        private BlurLayer
                noBlur,
                mediumBlur,
                highBlur;
        private Polygon3D 
                highBlurShape,
                medBlurUL,
                medBlurUR,
                medBlurLR,
                medBlurLL;
        private ArrayPoint[][] allPoints;
        Container(World myWorld, ArrayPoint upperLeft, ArrayPoint upperRight, ArrayPoint lowerRight, ArrayPoint lowerLeft, double mediumBlurDistance, double highBlurDistance, double disappearDistance, Supplier<View> view)
            {
                super(view);
                this.myWorld = myWorld;
                this.upperLeft = upperLeft;
                this.upperRight = upperRight;
                this.lowerRight = lowerRight;
                this.lowerLeft = lowerLeft;
                this.highBlurDistance = highBlurDistance;
                this.mediumBlurDistance = mediumBlurDistance;
                this.disappearDistance = disappearDistance;
                
                
                
                
                center = Point3D.getCenter(upperLeft,upperRight,lowerRight,lowerLeft);
                noBlur = new BlurLayer(center,-1,mediumBlurDistance,view)
                {
                    protected boolean showCondition()
                    {
                        double distance = center.getHorizontalDistance(view.get());
                        return (
                                
                                super.showCondition() &&  
                                (Calculations.angleDifference(view.get().getHorizontalDirection(center),view.get().getHR()) < definitionOfAngleInFront/2)
                                
                                )
                                
                                || distance < guaranteedActivationDistance;
                    }
                };
                mediumBlur = new BlurLayer(center,mediumBlurDistance,highBlurDistance,view)
                {
                    protected boolean showCondition()
                    {
                        double distance = center.get3DDistance(view.get());
                        return (
                                
                                super.showCondition() &&  
                                (Calculations.angleDifference(view.get().getHorizontalDirection(center),view.get().getHR()) < definitionOfAngleInFront/2)
                                
                                );
                    }
                };
                highBlur = new BlurLayer(center,highBlurDistance,disappearDistance,view)
                {
                    protected boolean showCondition()
                    {
                        double distance = center.get3DDistance(view.get());
                        return (
                                
                                super.showCondition() &&  
                                (Calculations.angleDifference(view.get().getHorizontalDirection(center),view.get().getHR()) < definitionOfAngleInFront/2)
                                
                                );
                    }
                };
                
                
                this.view = view;
                
                
                
                UL = upperLeft;
                UR = upperRight;
                LR = lowerRight;
                LL = lowerLeft;
                allPoints = myWorld.getPoints();
                
                if(LR.isOutOfBounds())
                {
                    if(UR.isOutOfBounds() && LL.isOutOfBounds())
                    {
                        LR = allPoints[allPoints.length - 1][allPoints[0].length - 1];
                    }
                    else if(UR.isOutOfBounds())
                    {
                        LR = allPoints[LR.getRow()][allPoints[0].length - 1];
                    }
                    else if(LL.isOutOfBounds())
                    {
                        LR = allPoints[allPoints.length - 1][LR.getColumn()];
                    }
                    
                }
                if(UR.isOutOfBounds())
                {
                    UR = allPoints[UR.getRow()][allPoints[0].length - 1];
                }
                if(LL.isOutOfBounds())
                {
                    LL = allPoints[allPoints.length - 1][LL.getColumn()];
                }
                highBlurShape = new Polygon3D(Color.BLACK,view,UL,UR,LR,LL);
                highBlur.add(highBlurShape);
                addBlurLayer(highBlur);
                
                
                
                int middleRow = (UL.getRow() + LL.getRow())/2;
                int middleCol = (UL.getColumn() + UR.getColumn())/2;
                
                north = allPoints[UL.getRow()][middleCol];
                south = allPoints[LL.getRow()][middleCol];;
                east = allPoints[middleRow][UR.getColumn()];
                west = allPoints[middleRow][UL.getColumn()];
                middle = allPoints[middleRow][middleCol];
                
                medBlurUL = new Polygon3D(Color.BLACK,view,UL,north,middle,west);
                medBlurUR = new Polygon3D(Color.BLACK,view,north,UR,east,middle);
                medBlurLR = new Polygon3D(Color.BLACK,view,middle,east,LR,south);
                medBlurLL = new Polygon3D(Color.BLACK,view,west,middle,south,LL);
                
                mediumBlur.add(medBlurUL);
                mediumBlur.add(medBlurUR);
                mediumBlur.add(medBlurLR);
                mediumBlur.add(medBlurLL);
                
                addBlurLayer(mediumBlur);
                
                addBlurLayer(noBlur);
                
                
                
                
            }
        /**
         * This constructor for dead container
         */
        Container(){super(null);}
        
        public double getHighestProbabilityActivation(){return highestProbabilityActivation;}
        public double getLowestProbabilityActivation(){return lowestProbabilityActivation;}
        public double getHighestProbabilityDectivation(){return highestProbabilityDeactivation;}
        public double getLowestProbabilityDeactivation(){return lowestProbabilityDeactivation;}
        public void setHighestProbabilityActivation(double d){highestProbabilityActivation = d;}
        public void setLowestProbabilityActivation(double d){lowestProbabilityActivation = d;}
        public void setHighestProbabilityDeactivation(double d){highestProbabilityDeactivation = d;}
        public void setLowestProbabilityDeactivation(double d){lowestProbabilityDeactivation = d;}
        public double getDefinitionOfAngleInFront(){return definitionOfAngleInFront;}
        public void setDefinitionOfAngleInFront(double d){definitionOfAngleInFront = d;}
        
        public BlurLayer getNoBlur(){return noBlur;}
        public BlurLayer getMediumBlur(){return mediumBlur;}
        public BlurLayer getHighBlur(){return highBlur;}
        
        public void scaleToNewDisappearDistance(double d)
        {
            double ratio = d/disappearDistance;
            mediumBlurDistance *= ratio;
            highBlurDistance *= ratio;
            
            
        }
        
        protected void looiStep()
            {
                if(super.needToInitialize())
                {
                    highBlurShape.useColor(myWorld.findAvgColor(UL.getRow(),UL.getColumn(),LR.getRow(),LR.getColumn()));
                    medBlurUL.useColor(myWorld.findAvgColor(UL.getRow(),UL.getColumn(),middle.getRow(),middle.getColumn()));
                    medBlurUR.useColor(myWorld.findAvgColor(north.getRow(),north.getColumn(),east.getRow(),east.getColumn()));
                    medBlurLR.useColor(myWorld.findAvgColor(middle.getRow(),middle.getColumn(),LR.getRow(),LR.getColumn()));
                    medBlurLL.useColor(myWorld.findAvgColor(west.getRow(),west.getColumn(),south.getRow(),south.getColumn()));
                }
                
                
                
                
                
                super.looiStep();
                    
            }
        
        
        public boolean hasContainedLooiObject(LooiObject l)
        {
            return super.hasComponent(l);
        }
        @Override
        public void activate()
        {
            super.activateSelf();
        }
        @Override
        public void deactivate()
        {
            super.deactivateSelf();
        }
        
        public Point3D getCenter(){return super.getCenter();}
        public double getGuaranteedActivationDistance(){return guaranteedActivationDistance;}
        
    }