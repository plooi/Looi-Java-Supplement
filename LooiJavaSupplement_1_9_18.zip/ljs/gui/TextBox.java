/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author peter_000
 */
public class TextBox extends Component
{
    private JTextArea textArea;
    public TextBox()
    {
        super(new JScrollPane(new JTextArea()));
        textArea = (JTextArea)(( javax.swing.JViewport)((JScrollPane)getJavaComponent()).getComponent(0)).getComponents()[0];
    }
    public String getText()
    {
        return textArea . getText ( ) ; 
    }
    public void setText(String text)
    {
        textArea . setText ( text ) ; 
    }
    public void setEditable(Boolean b)
    {
        textArea . setEditable ( b ) ; 
    }
    public Boolean isEditable()
    {
        return ( ( javax.swing.JTextArea ) getJavaComponent ( ) ) . isEditable ( ) ; 
    }
    public void wrapAroundWords(Boolean b)
    {
        textArea . setWrapStyleWord ( b ) ; 
    }
    public void wrapLine(Boolean b)
    {
        textArea . setLineWrap ( b ) ; 
    }
    public void scrollTo(Integer percentage)
    {
        ((JScrollPane)getJavaComponent()) . getVerticalScrollBar ( ) . setValue ( percentage ) ; 
    }
    public JTextArea getJTextArea()
    {
        return textArea;
    }
}
